from classes.Collider import Collider
from classes.EntityCollider import EntityCollider
from entities.EntityBase import EntityBase
from classes.Animation import Animation
from classes.Maths import Vec2D

class Flag(EntityBase):
    def __init__(self, screen, spriteColl, x, y, level):
        super(Flag, self).__init__(y, x, 0)  # Gravity set to 0 as flags don't fall
        self.spriteCollection = spriteColl
        self.screen = screen
        self.levelObj = level
        self.collision = Collider(self, level)
        self.EntityCollider = EntityCollider(self)
        self.type = "Flag"
        # self.animation = Animation([self.spriteCollection.get("flag").image])

    def update(self, camera):
       # self.drawFlag(camera)
        self.checkEntityCollision()

  #  def drawFlag(self, camera):
        #flag_image = self.spriteCollection.image  # Directly access the image attribute
        # print("REB_987", flag_image.spriteSheetURL)
       # self.screen.blit(flag_image, (self.rect.x + camera.x, self.rect.y)) 
            
    def checkEntityCollision(self):
        
        for ent in self.levelObj.entityList:
            collisionState = self.EntityCollider.check(ent)
            
            if ent.type == "Player":
                print("DB: Hola")
                if collisionState.isColliding :
                    print("DB: Hola2")
                    self.onPlayerCollision(ent)

    def onPlayerCollision(self, player):
        print("Player has reached the flag!")
        # Handle level completion logic here
