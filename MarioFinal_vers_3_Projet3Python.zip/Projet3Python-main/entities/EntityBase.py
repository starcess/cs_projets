import pygame

from classes.Maths import Vec2D


class EntityBase(object):
    def __init__(self, x, y, gravity):
        self.vel = Vec2D()
        self.rect = pygame.Rect(x * 32, y * 32, 32, 32)
        self.gravity = gravity
        self.traits = None
        self.alive = True
        self.active = True
        self.bouncing = False
        self.timeAfterDeath = 5
        self.timer = 0
        self.type = ""
        self.onGround = False
        self.obeyGravity = True

# decsend les persos au fur et à mesure que le temps avance 
    def applyGravity(self):
        if self.obeyGravity:
            self.vel.y += self.gravity

# rafraichir l'image selon l'état de l'entité
    def updateTraits(self):
        for trait in self.traits.values():
            try:
                trait.update()
            except AttributeError:
                pass

# indique la position de l'entité dans l'espace
    def getPosIndex(self):
        return Vec2D(self.rect.x // 32, self.rect.y // 32)

# indique la position en chiffre a virgule
    def getPosIndexAsFloat(self):
        return Vec2D(self.rect.x / 32.0, self.rect.y / 32.0)
