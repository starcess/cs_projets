//
//  Score+CoreDataClass.swift
//  MOMr_LUAz_201234567_201234567_labo3
//
//  Created by Zi Heng Liu (Étudiant) on 2023-11-28.
//
//

import Foundation
import CoreData


public class Score: NSManagedObject {
    
    private let context = CoreDataStack.sharedInstance.viewContext
    
    var getFormattedDate: String {
        return self.date!.formatted(date: .numeric, time: .omitted)
    }

    func isHighscore() -> Bool {
        return true
    }
    
    func toString() -> String {
        let usernameKey = DataList.UserDefaultsKeys.defaultUsername.rawValue
        let defaultUsername = UserDefaults.standard.string(forKey: usernameKey)
        
        return """
        \(self.username ?? defaultUsername!) : \(self.scorepoint.formatTwoDecimals()) - \(self.getFormattedDate)
        """
    }
    
//    func loadScores() -> [NSManagedObject] {
//        let context = CoreDataStack.sharedInstance.viewContext
//        let fetchRequest = NSFetchRequest<NSManagedObject>(NSFetchRequest(entityName: "Score"))
//        
//        do {
//            let entities = try context.fetch(fetchRequest)
//            return entities
//        } catch {
//            print("Failed to fetch entities: \(error)")
//            return []
//        }
//    }
    
//    func fetchTopScores(gametype: String, limit: Int = 5) -> {
//        let fetchRequest: NSFetchRequest<Entity>
//        fetchRequest = Entity.fetchRequest()
//
//        fetchRequest.predicate = NSPredicate(
//            format: "name LIKE %@", "Robert"
//        )
//
//        // Get a reference to a NSManagedObjectContext
//        let context = persistentContainer.viewContext
//
//        // Perform the fetch request to get the objects
//        // matching the predicate
//        let objects = try context.fetch(fetchRequest)
//    }
}
