//
//  CoreDataStack.swift
//  MOMr_LUAz_201234567_201234567_labo3
//
//  Created by Zi Heng Liu (Étudiant) on 2023-11-28.
//

import Foundation
import CoreData

class CoreDataStack {
    static let sharedInstance = CoreDataStack()
    
    // MARK: - Private
    private lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "Hangman")
        
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    private var fetchRequest: NSFetchRequest<Score> {
        return NSFetchRequest<Score>(entityName: "Score")
    }
    
    var myProperty: AnyObject?
    
    var viewContext: NSManagedObjectContext {
        return CoreDataStack.sharedInstance.persistentContainer.viewContext
    }
    
    //
    
    private func save() -> Bool {
        if self.viewContext.hasChanges {
            do {
                try self.viewContext.save()
                return true
            } catch {
                print("Error while saving: \(error)")
            }
        }
        
        return false
    }
    
    private func fetch(request: NSFetchRequest<Score>) -> [Score]? {
        do {
            let scores = try self.viewContext.fetch(request)
            return scores
        } catch {
            print("Error while fetching scores: \(error)")
        }
        
        return nil
    }
    
    private func fetchOne(request: NSFetchRequest<Score>) -> Score? {
        request.fetchLimit = 1
        
        do {
            let score = try self.viewContext.fetch(request)
            return score.first
        } catch {
            print("Error while fetching score: \(error)")
        }
        
        return nil
    }
    
    func deleteScore(score: Score) {
        self.viewContext.delete(score)
        
        do {
            try self.viewContext.save()
        } catch {
            print("Error while deleting score: \(error)")
        }
    }
    
    func deleteAllScores() {
        let scores = self.getAllScores()!
        
        for score in scores {
            self.viewContext.delete(score)
        }
        
        do {
            try self.viewContext.save()
        } catch {
            print("Error while deleting scores: \(error)")
        }
    }
    
    //
    
    func saveScore(username: String, gametype: String, scorepoint: Double) -> Bool {
        let score = NSEntityDescription.insertNewObject(forEntityName: "Score", into: self.viewContext) as! Score
        
        let usernameKey = DataList.UserDefaultsKeys.defaultUsername.rawValue
        let defaultUsername = UserDefaults.standard.string(forKey: usernameKey)
        
        score.username = username.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? defaultUsername : username
        score.gametype = gametype
        score.scorepoint = scorepoint
        score.date = Date()
        
        return self.save()
    }
    
    func getAllScores() -> [Score]? {
        let fetchRequest = NSFetchRequest<Score>(entityName: "Score")
        
        return self.fetch(request: fetchRequest)
    }
    
    // Could make a system to customize request with more functions
    func getScores(fromGametype gametype: String, withLimit limit: Int = 5) -> [Score]? {
        let request = self.fetchRequest
        request.predicate = NSPredicate(format: "gametype == %@", gametype)
        request.sortDescriptors = [NSSortDescriptor(key: "scorepoint", ascending: false)]
        request.fetchLimit = limit
        
        return self.fetch(request: request)
    }
}
