//
//  VC_Scores.swift
//  MOMr_LUAz_201234567_201234567_labo3
//
//  Created by Rébecca Dauphnie Mombrun (Étudiant) on 2023-11-27.
//

import UIKit

class VC_movieScores: ScoreScreen {
    
    @IBOutlet weak var scoresLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.gametype = DataList.UserDefaultsValues.movie.rawValue
        self.scoresLabel.text = self.getScores
    }
    
    
}
