//
//  VC_TitlePage.swift
//  MOMr_LUAz_201234567_201234567_labo3
//
//  Created by Rébecca Dauphnie Mombrun (Étudiant) on 2023-11-22.
//

import UIKit
import AVFoundation

class VC_TitlePage: UIViewController{
    
    let themeManager = ThemeManager.shared
    let soundEffectsManager = SoundEffectsManager.shared
    var audioPlayer: AVAudioPlayer?
    let musicVolumeManager =   MusicManager.shared
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUserDefault()
        musicVolumeManager.setVolume(UserDefaults.standard.float(forKey: DataList.UserDefaultsKeys.musicVolume.rawValue))
        soundEffectsManager.setVolume(UserDefaults.standard.float(forKey: DataList.UserDefaultsKeys.soundEffectsVolume.rawValue))
        self.view.applyChosenTheme()
        musicVolumeManager.playBackgroundMusic()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.view.applyChosenTheme()
        setDefaultVolumeValues()
    }
    
    func setUserDefault() {
        let hasLaunchedKey = "hasLaunched"
        let hasLaunched = UserDefaults.standard.bool(forKey: hasLaunchedKey)
        print("hasLaunched already : ", hasLaunched)
        if !hasLaunched {
            let defaultUsernameValue = DataList.UserDefaultsValues.defaultUsername.rawValue
            let englishLanguageValue = DataList.Languages.English.rawValue
            let isdarkMode = DataList.UserDefaultsKeys.isdarkMode.rawValue
            let defaultUsernameKey = DataList.UserDefaultsKeys.defaultUsername.rawValue
            let languageKey = DataList.UserDefaultsKeys.language.rawValue
            let soundEffectsVolumeKey = DataList.UserDefaultsKeys.soundEffectsVolume.rawValue
            let musicVolumeKey = DataList.UserDefaultsKeys.musicVolume.rawValue
            
            UserDefaults.standard.set(false, forKey: isdarkMode)
            UserDefaults.standard.set(defaultUsernameValue, forKey: defaultUsernameKey)
            UserDefaults.standard.set(englishLanguageValue, forKey: languageKey)
            UserDefaults.standard.set(0.5, forKey: soundEffectsVolumeKey)
            UserDefaults.standard.set(0.5, forKey: musicVolumeKey)
            
            UserDefaults.standard.set(true, forKey: hasLaunchedKey)
        }
    }
    
    func setDefaultVolumeValues() {
        let soundEffectsVolumeKey = DataList.UserDefaultsKeys.soundEffectsVolume.rawValue
        let musicVolumeKey = DataList.UserDefaultsKeys.musicVolume.rawValue
        
        let musicVolume = UserDefaults.standard.float(forKey: musicVolumeKey)
        musicVolumeManager.setVolume(musicVolume)
        
        let soundEffectVolume = UserDefaults.standard.float(forKey: soundEffectsVolumeKey)
        soundEffectsManager.setVolume(soundEffectVolume)
    }
    
}
