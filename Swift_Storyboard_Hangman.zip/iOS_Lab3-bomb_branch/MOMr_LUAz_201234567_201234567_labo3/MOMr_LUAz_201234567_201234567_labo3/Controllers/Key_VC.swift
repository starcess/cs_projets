//
//  Key_VC.swift
//  MOMr_LUAz_201234567_201234567_labo3
//
//  Created by Paige Wills on 2023-11-20.
//

import UIKit

class Key_VC: UICollectionViewCell {
    let imageView = UIImageView()
    let letterLabel = UILabel()
    
    var isValid = true {
        didSet {
            self.updateImage()
        }
    }
    
    override var isHighlighted: Bool {
        didSet {
            self.updateImage()
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.addSubview(self.imageView)
        self.imageView.translatesAutoresizingMaskIntoConstraints = false
        self.imageView.topAnchor.constraint(equalTo: self.topAnchor).isActive = true
        self.imageView.leftAnchor.constraint(equalTo: self.leftAnchor).isActive = true
        self.imageView.rightAnchor.constraint(equalTo: self.rightAnchor).isActive = true
        self.imageView.bottomAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
        self.imageView.contentMode = .scaleAspectFit
        
        self.addSubview(self.letterLabel)
        self.letterLabel.font = UIFont.boldSystemFont(ofSize: 20)
        self.letterLabel.translatesAutoresizingMaskIntoConstraints = false
        self.letterLabel.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        self.letterLabel.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setImage(name: String) {
        self.imageView.image = UIImage(named: name)
    }
    
    func updateImage() {
        if !isHighlighted && isValid {
            self.setImage(name: "key_up")
        } else if isHighlighted && isValid {
            self.setImage(name: "key_mid")
        } else {
            self.setImage(name: "key_down")
        }
    }
}
