//
//  UIViews.swift
//  MOMr_LUAz_201234567_201234567_labo3
//
//  Created by Zi Heng Liu (Étudiant) on 2023-11-28.
//

import UIKit

// Extensions

extension UIView {
    
    func applyChosenTheme() {
        let themeManager = ThemeManager.shared
        let key = DataList.UserDefaultsKeys.isdarkMode.rawValue
        let isDarkMode = UserDefaults.standard.bool(forKey: key)
        
        themeManager.findAllLabelsInViews(view: self)
        themeManager.applyDarkOrLightMode(view: self, darkModeOn: isDarkMode)
    }
    
}
// Custom Classes

class CustomViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.applyChosenTheme()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.view.applyChosenTheme()
    }
}

class ScoreScreen: CustomViewController {
    let themeManager = ThemeManager.shared
    let soundEffectsManager = SoundEffectsManager.shared
    
    var gametype: String = ""
    
    var getScores: String {
        if let scores = CoreDataStack.sharedInstance.getScores(fromGametype: self.gametype) {
            var result: String = ""
            
            for score in scores {
                result.append(score.toString() + "\n")
            }
            
            return result
        }
        
        return "No result found"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}
