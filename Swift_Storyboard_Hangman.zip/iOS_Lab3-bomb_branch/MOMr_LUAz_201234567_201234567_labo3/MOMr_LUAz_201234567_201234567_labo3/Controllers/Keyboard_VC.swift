//
//  AlphabetKeyboard_VC.swift
//  MOMr_LUAz_201234567_201234567_labo3
//
//  Created by Paige Wills on 2023-11-20.
//

protocol KeyboardVCDelegate: AnyObject {
    func keyWasTapped(_ key: Character)
}

import UIKit

class Keyboard_VC: UIViewController, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    private let cellLength = 48
    
    weak var delegate: KeyboardVCDelegate?
    
    var selectedKey : String?
    var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let layout = UICollectionViewFlowLayout()
        self.collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        self.view.addSubview(self.collectionView)
        
        self.collectionView.translatesAutoresizingMaskIntoConstraints = false
        self.collectionView.topAnchor.constraint(equalTo: view.topAnchor, constant: 10).isActive = true
        self.collectionView.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 10).isActive = true
        self.collectionView.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -10).isActive = true
        self.collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -10).isActive = true
        
        self.collectionView.dataSource = self
        self.collectionView.delegate = self
        self.collectionView.register(Key_VC.self, forCellWithReuseIdentifier: "cell")
        
        self.collectionView.backgroundColor = .darkGray
    }
    
    // MARK: - UICollectionViewDataSource
    
    func getCellAt(indexpath: IndexPath) -> Key_VC {
        return self.collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexpath) as! Key_VC
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return alphabetArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: self.cellLength, height: self.cellLength)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = self.getCellAt(indexpath: indexPath)
        let char = alphabetArray[indexPath.item]
        
        cell.letterLabel.text = String(char)
        cell.isValid = !(Hangman.getMappedChars[char] ?? false)

        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let char = alphabetArray[indexPath.item]
        delegate?.keyWasTapped(char)
        
        let cell = self.collectionView.cellForItem(at: indexPath) as! Key_VC
        cell.isValid = !Hangman.getMappedChars[char]!
    }
}
