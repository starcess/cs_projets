//
//  VC_retryPage.swift
//  MOMr_LUAz_201234567_201234567_labo3
//
//  Created by Rébecca Dauphnie Mombrun (Étudiant) on 2023-11-23.
//
import UIKit


class VC_infoPage: UIViewController {
  
    @IBOutlet weak var lbl_gameType: UILabel!
    @IBOutlet weak var lbl_gameAideInfo: UILabel!
    
    
    let soundEffectsManager = SoundEffectsManager.shared
    let themeManager = ThemeManager.shared
    
    var info : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.applyChosenTheme()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        changeLabelsText()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        print("MODAL viewWillDisappear")
    }
    
    func changeLabelsText() {
        let key = DataList.UserDefaultsKeys.gameType.rawValue
        let mode = UserDefaults.standard.string(forKey: key) ?? ""
        
        lbl_gameType.text =  "\(mode) Mode"
        lbl_gameAideInfo.text = info
    }
    
}
