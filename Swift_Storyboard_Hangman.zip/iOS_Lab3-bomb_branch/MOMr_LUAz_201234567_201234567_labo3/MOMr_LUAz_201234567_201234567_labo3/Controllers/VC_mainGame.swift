//
//  ViewController.swift
//  MOMr_LUAz_201234567_201234567_labo3
//
//  Created by Rébecca Dauphnie Mombrun (Étudiant) on 2023-11-20.
//

import UIKit

class VC_mainGame: UIViewController, KeyboardVCDelegate {
   
    @IBOutlet weak var gameStack: UIStackView!
    @IBOutlet weak var quitKey: UIImageView!
    @IBOutlet weak var infoKey: UIImageView!
    @IBOutlet weak var resetKey: UIImageView!
    @IBOutlet weak var livesImage: UIImageView!
    @IBOutlet weak var displayLabel: UILabel!
    
    let game = Hangman.shared
    let themeManager = ThemeManager.shared
    let soundEffectsManager = SoundEffectsManager.shared
    
    var gameMode : Any?
    
    var keyboardVC : Keyboard_VC!
    var infoPageVC : VC_infoPage!
    
    var getConsoleDisplayText: String {
        return """
            C:\\Bomb\\INFO> Diff: \(self.game.difficulty.formatTwoDecimals()) - Score: \(self.game.score.formatTwoDecimals())
            C:\\Bomb\\PASSWORD> \(self.game.displayString)
            """
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.applyChosenTheme()
        self.displayLabel.tag = 40
        self.displayLabel.textColor = .green
        self.displayLabel.backgroundColor = .black
        self.refresh()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tabBarController?.tabBar.isHidden = true
        self.navigationItem.hidesBackButton = true
    
        self.initializeKeyboardVC()
        self.refresh()
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segueToInfoPage" {
            if let destinationVC = segue.destination as? VC_infoPage {
                destinationVC.info = game.wordHelpInfo
            }
        }
    }
    
    
    @IBAction func detectedTapGestureOnResetKey(_ sender: Any) {
        self.refresh()
        self.newGame()
    }
    

    // Delegate function from keyboard_VC protocol
    func keyWasTapped(_ keyText: Character)  {
        let isCorrectGuess = game.makeGuess(char: keyText)
        
        print(" is correct guess \(isCorrectGuess)")
        showVcGameEnd()
        soundEffectsManager.playClickSound()
        refresh()
    }
    
    func initializeKeyboardVC() {
        if let kb_vc = children.first(where: { $0 is Keyboard_VC }) as? Keyboard_VC {
            self.keyboardVC = kb_vc
            self.keyboardVC!.delegate = self
        }
    }
    
    // https://stackoverflow.com/questions/39450124/swift-programmatically-navigate-to-another-view-controller-scene
    func showVcGameEnd() {
        if (!game.isOngoing) {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            if let gameEnd_vc = storyboard.instantiateViewController(withIdentifier: "gameEnd_Scene") as? VC_gameEnd {
                let key = DataList.UserDefaultsKeys.gameType.rawValue
                
                gameEnd_vc.gametype = UserDefaults.standard.string(forKey: key)!
                print(UserDefaults.standard.string(forKey: key)!)
                self.show(gameEnd_vc, sender: self)
            }
        }
    }
    
    func refresh() {
        print("refresh ")
        self.livesImage.image = UIImage(named: "lives_\(self.game.lives)")
        self.displayLabel.text = self.getConsoleDisplayText
        print(" C:\\Users\\Bomb\\Documents\\RESULT>...lives = \(self.game.lives)  || mysteryWord = \(self.game.displayString) || answer = \(self.game.answer) ")
    }
    
    func resetKeyboard() {
        self.keyboardVC.collectionView.reloadData()
    }
    
    func setNewMovieGame() {
        gameMode = MovieGame.shared
        
        (gameMode as? MovieGame)?.startGame(
            completion: { [weak self] in
                guard let self = self else { return }
                
                let answer = (self.gameMode as? MovieGame)?.movieTitle ?? ""
                let answerInfo = (self.gameMode as? MovieGame)?.sendMovieInfo() ?? ""
                let key = DataList.UserDefaultsKeys.gameType.rawValue
                let movieTypeValue = DataList.UserDefaultsValues.movie.rawValue
                
                self.game.newGame(word: answer, info: answerInfo)
                UserDefaults.standard.set(movieTypeValue, forKey: key)
                self.refresh()
                resetKeyboard()
            }
        )
    }
    
    func setNewEngGame() {
        gameMode = EnglishWordGame.shared
        
        (gameMode as? EnglishWordGame)?.startGame(
            completion: { [weak self] in
                guard let self = self else { return }
                
                let answer = (self.gameMode as? EnglishWordGame)?.randomWord ?? ""
                let answerInfo = (self.gameMode as? EnglishWordGame)?.sendWordDefinition() ?? ""
                let key = DataList.UserDefaultsKeys.gameType.rawValue
                let engWordTypeValue = DataList.UserDefaultsValues.word.rawValue
                
                self.game.newGame(word: answer, info: answerInfo)
                self.refresh()
                resetKeyboard()
                UserDefaults.standard.set(engWordTypeValue, forKey: key)
            }
        )
    }
    
    func newGame() {
        let key = DataList.UserDefaultsKeys.gameType.rawValue
        let gameType = UserDefaults.standard.string(forKey: key)
        
        if gameType == DataList.UserDefaultsValues.word.rawValue {
            self.setNewEngGame()
        } else {
            self.setNewMovieGame()
        }

    }
}






