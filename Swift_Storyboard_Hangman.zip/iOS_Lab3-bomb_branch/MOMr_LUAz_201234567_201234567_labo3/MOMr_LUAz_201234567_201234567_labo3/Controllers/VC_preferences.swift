//
//  VC_preferences.swift
//  MOMr_LUAz_201234567_201234567_labo3
//
//  Created by Rébecca Dauphnie Mombrun (Étudiant) on 2023-11-24.
//

import UIKit
import GameKit

class VC_preferences: UIViewController , UIPickerViewDataSource, UIPickerViewDelegate{
    
    @IBOutlet weak var txtF_defaultUsername: UITextField!
    @IBOutlet weak var isDarkMode_Switch: UISwitch!
    @IBOutlet weak var pickerView_languages: UIPickerView!
    @IBOutlet weak var musicVolume_slider: UISlider!
    @IBOutlet weak var soundEffectVolume_slider: UISlider!
    
    let musicVolumeManager =  MusicManager.shared
    let themeManager = ThemeManager.shared
    let soundEffectsManager = SoundEffectsManager.shared
    
    var languageList: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.applyChosenTheme()
        self.pickerView_languages.reloadAllComponents()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        populateLanguageList()
        setPickerViewToDefaultValue()
        self.view.applyChosenTheme()
        setElementsDefaultValue()
        self.pickerView_languages.reloadAllComponents()
    }
    
    @IBAction func changingMusicVolume(_ sender: UISlider) {
        let newVolume = sender.value
        
        UserDefaults.standard.set(newVolume, forKey: DataList.UserDefaultsKeys.musicVolume.rawValue)
        musicVolumeManager.setVolume(newVolume)
    }
    
    @IBAction func changingSoundEffectsVolume(_ sender: UISlider) {
        let newVolume = sender.value
        
        UserDefaults.standard.set(newVolume, forKey: DataList.UserDefaultsKeys.soundEffectsVolume.rawValue)
        soundEffectsManager.setVolume(newVolume)
    }
    
    @IBAction func clickedIsDarkModeOn(_ sender: UISwitch) {
        let key = DataList.UserDefaultsKeys.isdarkMode.rawValue
        let isDarkMode = sender.isOn
        
        UserDefaults.standard.set(isDarkMode, forKey: key)
        self.view.applyChosenTheme()
        self.pickerView_languages.reloadAllComponents()
    }
    
    
    @IBAction func validatedUsername(_ sender: Any) {
        let username = txtF_defaultUsername.text
        
        if(!(username!.trimmingCharacters(in: .whitespacesAndNewlines)).isEmpty){
            let usernameKey = DataList.UserDefaultsKeys.defaultUsername.rawValue
            
            UserDefaults.standard.set(username, forKey: usernameKey)
        }else{
            let usernameKey = DataList.UserDefaultsKeys.defaultUsername.rawValue
            let defaultUsername = DataList.UserDefaultsValues.defaultUsername.rawValue
            
            UserDefaults.standard.set(defaultUsername, forKey: usernameKey)
            txtF_defaultUsername.text = defaultUsername
        }
    }
    
    
    func populateLanguageList(){
        let languagesEnums = DataList.Languages.allCases
        
        for language in languagesEnums {
            languageList.append(language.rawValue)
        }
    }
    
    func setElementsDefaultValue() {
        let musicVolumeKey = DataList.UserDefaultsKeys.musicVolume.rawValue
        let musicVolume = UserDefaults.standard.float(forKey: musicVolumeKey)
        musicVolume_slider.value = musicVolume

        let soundEffectsVolumeKey = DataList.UserDefaultsKeys.soundEffectsVolume.rawValue
        let soundEffectsVolume = UserDefaults.standard.float(forKey: soundEffectsVolumeKey)
        soundEffectVolume_slider.value = soundEffectsVolume

        let usernameKey = DataList.UserDefaultsKeys.defaultUsername.rawValue
        let defaultUsername = UserDefaults.standard.string(forKey: usernameKey)
        txtF_defaultUsername.text = defaultUsername
        
        
        let key = DataList.UserDefaultsKeys.isdarkMode.rawValue
        let isDarkMode = UserDefaults.standard.bool(forKey: key)
        isDarkMode_Switch.setOn(isDarkMode, animated: false)

        setPickerViewToDefaultValue()
    }
    
  
    
    func setPickerViewToDefaultValue() {
        let key = DataList.UserDefaultsKeys.language.rawValue
        let defaultValue = UserDefaults.standard.string(forKey: key) ?? "DefaultLanguage"

        if let defaultRowIndex = languageList.firstIndex(of: defaultValue) {
            pickerView_languages.selectRow(defaultRowIndex, inComponent: 0, animated: true)
        }
    }
    
    
    
    //Datasource
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return languageList.count
    }
    
    //Delegate
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return languageList[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        let key = DataList.UserDefaultsKeys.language.rawValue
        UserDefaults.standard.set(languageList[row], forKey: key)
    }
    
    func pickerView(_ pickerView: UIPickerView, attributedTitleForRow row: Int, forComponent component: Int) -> NSAttributedString? {
        let title = languageList[row]
        let key = DataList.UserDefaultsKeys.isdarkMode.rawValue
        let textColor = UserDefaults.standard.bool(forKey: key) ? ThemeManager.white : ThemeManager.black
        return NSAttributedString(string: title, attributes: [NSAttributedString.Key.foregroundColor: textColor])
    }
}

