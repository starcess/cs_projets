//
//  VC_gameEnd.swift
//  MOMr_LUAz_201234567_201234567_labo3
//
//  Created by Rébecca Dauphnie Mombrun (Étudiant) on 2023-11-21.
//

import UIKit

class VC_gameEnd: UIViewController {
    
    @IBOutlet weak var txtF_username: UITextField!
    @IBOutlet weak var lbl_WinOrLose: UILabel!
    @IBOutlet weak var lbl_answerAndScore: UILabel!
    
    let game = Hangman.shared
    let soundEffectsManager = SoundEffectsManager.shared
    let themeManager = ThemeManager.shared
    
    var gametype = ""
    
    var getEndgameStatus: String {
        return "GAME \(self.game.isWon ? "WON" : "OVER")"
    }
    
    var getEndgameResults: String {
        return """
            Password
            \(game.answer)
            
            Score
            \(game.score.formatTwoDecimals())
            """
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.hidesBackButton = true
        self.view.applyChosenTheme()
        
        self.lbl_WinOrLose.text = self.getEndgameStatus
        self.lbl_answerAndScore.text = self.getEndgameResults
        
        let usernameKey = DataList.UserDefaultsKeys.defaultUsername.rawValue
        let defaultUsername = UserDefaults.standard.string(forKey: usernameKey)
        txtF_username.placeholder = defaultUsername
        
//        print("VC_gameEnd - gametype : ", self.gametype)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.view.applyChosenTheme()
    }
    
    
    @IBAction func clickedBtnValidate(_ sender: Any) {
        let username = self.txtF_username.text ?? "Noname"
        
        if game.isWon && CoreDataStack.sharedInstance.saveScore(username: username,
                                                  gametype: self.gametype,
                                                  scorepoint: self.game.score) {
            print("Successfully saved")
        } else {
            print("Saving unsuccessful")
        }
        
        resetUserDefaultGameType()
    }
    
    func resetUserDefaultGameType() {
        let key = DataList.UserDefaultsKeys.gameType.rawValue
        UserDefaults.standard.removeObject(forKey:  key)
    }
    
    func saveHighscore() {
        let currentContext = CoreDataStack.sharedInstance.viewContext
        
        let newScore = Score(context: currentContext)
        newScore.username = self.txtF_username.text ?? "No name"
        newScore.gametype = self.gametype
        newScore.scorepoint = self.game.score
        newScore.date = Date()
        
        if newScore.isHighscore() {
            do {
                try currentContext.save()
                print("highscore sauvegardée avec succès!")
            } catch let error as NSError {
                print("Impossible de sauvegarder le score. \(error), \(error.userInfo)")
            }
        } else {
            print("Not a highscore")
        }
    }
    
}

extension VC_gameEnd {
    func saveScore(username: String, gametype: String, score: Double) {
        let currentContext = CoreDataStack.sharedInstance.viewContext
        
        let newScore = Score(context: currentContext)
        newScore.username = username
        newScore.gametype = gametype
        newScore.date = Date()
        
        if game.isWon {
            do {
                try currentContext.save()
                print("highscore sauvegardée avec succès!")
            } catch let error as NSError {
                print("Impossible de sauvegarder le score. \(error), \(error.userInfo)")
            }
        } else {
            print("Not a highscore")
        }
    }
}
