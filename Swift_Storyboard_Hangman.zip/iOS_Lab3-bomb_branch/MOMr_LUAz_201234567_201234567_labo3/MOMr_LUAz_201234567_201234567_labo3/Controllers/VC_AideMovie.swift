//
//  VC_movieStartPage.swift
//  MOMr_LUAz_201234567_201234567_labo3
//
//  Created by Rébecca Dauphnie Mombrun (Étudiant) on 2023-11-21.
//

import UIKit
import GameKit

class VC_AideMovie: UIViewController {
    
   
    @IBOutlet weak var aideTitleLabel: UILabel!
    @IBOutlet weak var aideContentLabel: UILabel!
    
    let game = Hangman.shared
    let movieGame = MovieGame.shared
    let themeManager = ThemeManager.shared
    let soundEffectsManager = SoundEffectsManager.shared
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.applyChosenTheme()

    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        self.newGame()
    }
    
    @IBAction func startMovieGame(_ sender: Any) {
        let key = DataList.UserDefaultsKeys.gameType.rawValue
        let gameTypeValue = DataList.UserDefaultsValues.movie.rawValue
        
        UserDefaults.standard.set(gameTypeValue, forKey: key)
        if let gameTypeValue = UserDefaults.standard.string(forKey: key) {
            print("VC_AideMovie - gameTypeValue : \(gameTypeValue)")
        } else {
            print("VC_AideMovie - gameTypeValue not found")
        }
    }
    
    //
    
    func newGame() {
        self.movieGame.startGame { [weak self] in
            let movieInfo = self?.movieGame.sendMovieInfo()
            
            self?.aideTitleLabel.text = "Movies Mode"
            self?.aideContentLabel.text = movieInfo
            self?.game.newGame(word: self?.movieGame.movieTitle ?? "", info: movieInfo ?? "")
        }
        
    }

}

