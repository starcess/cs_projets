//
//  VC_wordStartPage.swift
//  MOMr_LUAz_201234567_201234567_labo3
//
//  Created by Rébecca Dauphnie Mombrun (Étudiant) on 2023-11-21.
//

import UIKit

class VC_AideWord: UIViewController {
    
    @IBOutlet weak var lbl_definition: UILabel!
    @IBOutlet weak var lbl_modeTitle: UILabel!
    
    let game = Hangman.shared
    let englishWordGame = EnglishWordGame.shared
    let themeManager = ThemeManager.shared
    let soundEffectsManager = SoundEffectsManager.shared
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.applyChosenTheme()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        newGame()
    }
    
    @IBAction func startWordsGame(_ sender: Any) {
        let key = DataList.UserDefaultsKeys.gameType.rawValue
        let gameTypeValue = DataList.UserDefaultsValues.word.rawValue
        
        UserDefaults.standard.set(gameTypeValue, forKey: key)
        if let gameTypeValue = UserDefaults.standard.string(forKey: key) {
            print("VC_AideWord - gameTypeValue : \(gameTypeValue)")
        } else {
            print("VC_AideWord - gameTypeValue not found")
        }
    }
    
    
    func newGame() {
        englishWordGame.startGame { [weak self] in
            let wordDefinition = self?.englishWordGame.sendWordDefinition()
            
            self?.lbl_modeTitle.text = "English Words Mode"
            self?.lbl_definition.text = wordDefinition
            self?.game.newGame(word: self?.englishWordGame.randomWord ?? " ", info:wordDefinition ?? " ")
        }
    }
    

}


