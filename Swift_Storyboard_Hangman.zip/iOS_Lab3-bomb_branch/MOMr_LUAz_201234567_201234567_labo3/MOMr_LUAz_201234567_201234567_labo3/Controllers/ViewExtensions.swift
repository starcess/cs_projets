//
//  UIViews.swift
//  MOMr_LUAz_201234567_201234567_labo3
//
//  Created by Zi Heng Liu (Étudiant) on 2023-11-28.
//

import UIKit

extension UIView {
    
    
    func addRadius(amount: CGFloat = 15) {
        self.layer.cornerRadius = amount
        self.layer.masksToBounds = true
    }
    
    func applyChosenTheme() {
        //        let key = DataList.UserDefaultsKeys.isdarkMode.rawValue
        //        let isDarkMode = UserDefaults.standard.bool(forKey: key)
        //        let labelColor: UIColor = isDarkMode ? .white : .black
        //
        //        var subviews: [UIView] = [self]
        //        while !subviews.isEmpty {
        //            let currentView = subviews.removeFirst()
        //
        //            if currentView is UILabel && !(currentView.superview is UIButton) {
        //                currentView.backgroundColor = labelColor
        //            }
        //        }
        //
        //        self.backgroundColor = isDarkMode ? .black : .white
        let themeManager = ThemeManager.shared
        let key = DataList.UserDefaultsKeys.isdarkMode.rawValue
        let isDarkMode = UserDefaults.standard.bool(forKey: key)
        
        themeManager.findAllLabelsInViews(view: self)
        themeManager.applyDarkOrLightMode(view: self, darkModeOn: isDarkMode)
    }
}
