//
//  VC_engWordsScores.swift
//  MOMr_LUAz_201234567_201234567_labo3
//
//  Created by Rébecca Dauphnie Mombrun (Étudiant) on 2023-11-27.
//

import UIKit

class VC_engWordsScores: ScoreScreen {
    
    @IBOutlet weak var scoreLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.gametype = DataList.UserDefaultsValues.word.rawValue
        self.scoreLabel.text = self.getScores
    }
    
}
