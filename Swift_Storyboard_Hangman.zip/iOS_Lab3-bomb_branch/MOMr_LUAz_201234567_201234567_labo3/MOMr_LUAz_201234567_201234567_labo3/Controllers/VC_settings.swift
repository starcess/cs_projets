//
//  VC_settings.swift
//  MOMr_LUAz_201234567_201234567_labo3
//
//  Created by Rébecca Dauphnie Mombrun (Étudiant) on 2023-11-27.
//

import UIKit

class VC_settings: UIViewController {

    let themeManager = ThemeManager.shared
    let soundEffectsManager = SoundEffectsManager.shared

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.applyChosenTheme()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.view.applyChosenTheme()
    }

}
