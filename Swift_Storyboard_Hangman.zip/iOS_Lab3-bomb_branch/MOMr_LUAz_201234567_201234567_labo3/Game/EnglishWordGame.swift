//
//  EnglishWordGame.swift
//  MOMr_LUAz_201234567_201234567_labo3
//
//  Created by Rébecca Dauphnie Mombrun (Étudiant) on 2023-11-22.
//

import Foundation

class EnglishWordGame{
    
    var meaning : String = ""
    var randomWord : String = " "
    
    static let shared = EnglishWordGame() 
    
    private init() {}
    
    func startGame(completion: @escaping () -> Void) {
        fetchRandomWordAndDefinition {word, definition in
            DispatchQueue.main.async { [self] in
                meaning = definition
                randomWord = word

                completion()
            }
        }
    }
    
    func sendWordDefinition() -> String {
         let message = """
           Definition :
           \(self.meaning)
           """
        print("word: \(randomWord) =  \(meaning)")
        return message
   }
}



