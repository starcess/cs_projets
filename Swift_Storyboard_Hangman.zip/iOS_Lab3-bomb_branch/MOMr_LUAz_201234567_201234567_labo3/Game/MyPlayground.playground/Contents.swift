
//My playground

import UIKit
import PlaygroundSupport  //I put this here bc playgrounds dont care about completion handlers and I needed to wait for the asyc function to finish first.
//
//var greeting = "Hello, playground"
//
//
//let hello = "héllö wörld"
//
//print(hello)
//print(hello.normalizeForHangman == "hello world")
//
//let game = Hangman.shared
//
//game.newGame(word: hello)
//
//print(game.answer)
//
//print(game.getDifficulty())
//
//
//PlaygroundPage.current.needsIndefiniteExecution = true
//
//fetchRandomWordAndDefinition { word, definition in
//    print("Fetched word: \(word) with definition: \(definition)")
//    game.newGame(word: word)
//
//    DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
//        print("game.answer after fetch: \(game.answer)")
//        PlaygroundPage.current.finishExecution()
//    }
//}


