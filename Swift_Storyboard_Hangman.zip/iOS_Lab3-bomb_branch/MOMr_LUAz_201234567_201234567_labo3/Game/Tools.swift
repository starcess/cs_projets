//
//  Tools.swift
//  MOMr_LUAz_201234567_201234567_labo3
//
//  Created by Paige Wills on 2023-11-21.
//

import Foundation

// EXTENSIONS

extension String {
    // Removes accents and sets to lowercase, basis for other extensions specifically for Hangman game
    var normalizeForHangman: String {
        let mutableString = NSMutableString(string: self.lowercased()) as CFMutableString
        CFStringTransform(mutableString, nil, kCFStringTransformStripCombiningMarks, false)
        return mutableString as String
    }
    
    static func == (lhs: Character, rhs: String) -> Bool {
        return lhs == rhs.first
    }
    
    static func == (lhs: String, rhs: Character) -> Bool {
        return lhs.first == rhs
    }
    
    func hangmanEquals(other: String) -> Bool {
        return self.normalizeForHangman == other.normalizeForHangman
    }
}

extension Character {
    var normalizeForHangman: Character {
        let mutableString = String(self).normalizeForHangman
        return Character(mutableString)
    }
    
    func hangmanEquals(other: Character) -> Bool {
        return self.normalizeForHangman == other.normalizeForHangman
    }
}

extension Array where Element == String {
    func contains(char: Character) -> Bool {
        let charToString = String(char)
        return self.contains(charToString)
    }
    
    func hangmanContains(other: String) -> Bool {
        for element in self {
            if element.hangmanEquals(other: other) {
                return true
            }
        }
        
        return false
    }

    func hangmanContains(char: Character) -> Bool {
        return self.hangmanContains(other: String(char))
    }
}

extension Array where Element == Character {
    func contains(letter: String) -> Bool {
        let stringToChar = Character(letter)
        return self.contains(stringToChar)
    }
    
    func hangmanContains(char: Character) -> Bool {
        for character in self {
            if character.hangmanEquals(other: char) {
                return true
            }
        }
        
        return false
    }
}

extension Double {
    func formatTwoDecimals() -> String {
        return String(format: "%.2f", self)
    }
}

// COMPUTED VAR

var alphabetArray: [Character] {
    var alphabetArray: [Character] = []
    
    for scalarValue in UnicodeScalar("a").value...UnicodeScalar("z").value {
        if let char = UnicodeScalar(scalarValue) {
            alphabetArray.append(Character(char))
        }
    }
    
    return alphabetArray
}

// FUNCTIONS

// Deprecated for project
func normalizeChar(char: Character) -> Character {
    return Character(char.lowercased())
}

func uniqueLetters(word: String) -> [Character] {
    var uniqueLetters: [Character] = []
    
    for char in word {
        if !uniqueLetters.contains(char) && alphabetArray.contains(char) {
            uniqueLetters.append(char)
        }
    }
    
    return uniqueLetters
}

func countOccurences(word: String, char: Character) -> Int {
    var count = 0
    
    for charInWord in word {
        count += charInWord == char ? 1 : 0
    }
    
    return count
}





//


