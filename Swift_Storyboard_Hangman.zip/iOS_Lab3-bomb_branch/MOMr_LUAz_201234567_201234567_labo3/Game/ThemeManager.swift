//
//  ThemeManager.swift
//  MOMr_LUAz_201234567_201234567_labo3
//
//  Created by Rébecca Dauphnie Mombrun (Étudiant) on 2023-11-26.
//

import Foundation
import UIKit

class ThemeManager {
    
    static let shared = ThemeManager()
    static var black: UIColor = UIColor.black
    static var white: UIColor = UIColor.white
    var labelsList: [UILabel] = []
    var mainView: [UIView] = []
    
    private init() {}
    
    func applyDarkOrLightMode(view: UIView, darkModeOn: Bool) {
        if (darkModeOn) {
            view.backgroundColor = ThemeManager.black
            setLabelsToWhite()
            addRadiusToLabels()
        } else {
            view.backgroundColor = ThemeManager.white
            setLabelsToBlack()
            addRadiusToLabels()
        }
    }
    
    //        link explaining nested subviews
    //https://stackoverflow.com/questions/32301336/swift-recursively-cycle-through-all-subviews-to-find-a-specific-class-and-appen
    func findAllLabelsInViews(view: UIView) {
        var mainView: [UIView] = [view]
        
        while !mainView.isEmpty {
            let currentView = mainView.removeFirst()
            
            if (currentView is UILabel) && !(currentView.superview is UIButton) && !(currentView.superview is UITextField)  {
                labelsList.append(currentView as! UILabel)
            }
            
            mainView.append(contentsOf: currentView.subviews)
        }
    }
    
    func setLabelsToWhite() {
        for label in labelsList {
            if label.tag != 40{
                label.textColor = UIColor.white
            }
        }
    }
    
    func setLabelsToBlack() {
        for label in labelsList {
            if label.tag != 40{
                label.textColor = UIColor.black
            }
        }
    }
    
    func addRadiusToLabels(amount: CGFloat = 15) {
        for label in labelsList {
            if label.tag != 40{
                label.layer.cornerRadius = amount
                label.layer.masksToBounds = true
            }
        }
    }
    
    
}
