//
//  MovieDownloader.swift
//  JeuDuPendu
//
//  Created by Zi heng Liu on 2023-09-28.
//

import Foundation

class MovieGame {
    
    static let shared = MovieGame()
    
    var movieTitle: String = ""
    var releasedDate: String = ""
    var imdbRating: String = ""
    var genre: String = ""
    var director: String = ""
    var actors: String = ""
    var directorList : [String] = []
    var actorList : [String] = []
    
    private init() {}
    
    func startGame(completion: @escaping () -> Void) {
        getRandomMovie { [weak self] result in
            DispatchQueue.main.async { [self] in
                switch result {
                case .success(let movie):
                    self?.movieTitle = movie.title
                    self?.releasedDate = movie.releasedDate
                    self?.imdbRating = movie.imdbRating
                    self?.genre = movie.genre
                    self?.director = movie.director
                    self?.actors = movie.actors
                    self?.createDirectorAndActorList()
                    
                    //                        print ("Release date: \( self?.releasedDate), IMDb Rating: \( self?.imdbRating), Genre: \(self?.genre)")
                    completion()
                case .failure(let error):
                    print("Failed to fetch movie: \(error)")
                    completion()
                }
            }
        }
    }
    
    
    
    func createDirectorAndActorList(){
        directorList = self.director.split(separator: ",").map(String.init).prefix(2).map { String($0) }
        actorList = self.actors.split(separator: ",").map(String.init).prefix(3).map { String($0) }
    }
    
    
    func sendMovieInfo() -> String {
        
        let message = """
           Release date: \(self.releasedDate)
           IMDb Rating: \(self.imdbRating)
           Genre: \(self.genre)
           
           Directors:
           \(self.constructDirectorsString())
           
           Actors:
           \(self.constructActorsString())
           """
        //        print("message: \(message)")
        print("movieTitle: \(movieTitle)")
        return message
    }
    
    
    func constructActorsString() -> String {
        var actorString = ""
        
        if actorList.count >= 3 {
            for i in 0..<3 {
                actorString += "\(actorList[i])\n"
            }
        } else {
            for actor in actorList {
                actorString += "\(actor)\n"
            }
        }
        actorString = actorString.trimmingCharacters(in: .whitespacesAndNewlines)
        return actorString
    }
    
    
    func constructDirectorsString() -> String {
        var directorString = ""
        
        if directorList.count >= 2 {
            for i in 0..<2 {
                directorString += "\(directorList[i])\n"
            }
        } else {
            for director in directorList {
                directorString += "\(director)\n"
            }
        }
        directorString = directorString.trimmingCharacters(in: .whitespacesAndNewlines)
        return directorString
    }
    
}





