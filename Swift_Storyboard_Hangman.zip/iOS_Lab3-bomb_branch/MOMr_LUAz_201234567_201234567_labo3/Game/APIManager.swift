//
//  APIManager.swift
//  MOMr_LUAz_201234567_201234567_labo3
//
//  Created by Paige Wills on 2023-11-20.
//

import Foundation




struct Movie: Codable {
    let title: String
    let releasedDate: String
    let imdbRating: String
    let genre: String
    let director: String
    let actors: String

    private enum CodingKeys: String, CodingKey {
        case title = "Title"
        case releasedDate = "Released"
        case imdbRating = "imdbRating"
        case genre = "Genre"
        case director = "Director"
        case actors = "Actors"
    }
}

struct DictionaryWord: Codable {
    let word: String
    let meanings: [Meaning]

    private enum CodingKeys: String, CodingKey {
        case word = "word"
        case meanings = "meanings"
    }
}

struct Meaning: Codable {
    let partOfSpeech: String
    let definitions: [Definition]

    private enum CodingKeys: String, CodingKey {
        case partOfSpeech = "partOfSpeech"
        case definitions = "definitions"
    }
}


struct Definition: Codable {
    let definition: String
    let synonyms: [String]
    let antonyms: [String]

    private enum CodingKeys: String, CodingKey {
        case definition = "definition"
        case synonyms = "synonyms"
        case antonyms = "antonyms"
    }
}
