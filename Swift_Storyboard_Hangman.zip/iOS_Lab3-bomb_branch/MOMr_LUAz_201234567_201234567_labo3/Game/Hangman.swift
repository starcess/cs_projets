//
//  JeuPendu.swift
//  JeuDuPendu
//
//  Created by Zi heng Liu on 2023-09-28.
//

import Foundation

class Hangman {
    static let shared = Hangman()
    static let maxMisguesses: Int = 7
    
    var wordHelpInfo : String = ""
    var answer: String = ""
    var misguesses: Int = 0
    var mappedChars: [Character: Bool] = [:]
    
    private init() {
        for char in alphabetArray {
            self.mappedChars[char] = false
        }
    }
    
    // PROPERTIES
    
    static var getMappedChars: [Character: Bool] {
        return self.shared.mappedChars
    }
    
    var normalizedAnswer: String {
        return self.answer.normalizeForHangman
    }
    
    var difficulty: Double {
        var difficulty: Double = 0
        
        for char in uniqueLetters(word: self.normalizedAnswer) {
            let occurences = countOccurences(word: self.normalizedAnswer, char: char.normalizeForHangman)
            
            if let rate = DataList.frequencies[char] {
                difficulty += (1 - rate) / Double(occurences)
            }
        }
        
        return difficulty
    }
    
    var score: Double {
        var score: Double = 0

        for char in self.normalizedAnswer {
            if let rate = DataList.frequencies[char], self.mappedChars[char] == true {
                score += self.difficulty * (10 - 9 * rate)
            }
        }
        
        return score - Double(self.penalty)
    }
    
    var penalty: Int {
        return self.misguesses * self.misguesses * 5
    }
    
    var displayString: String {
        var result: String = "";
        
        for character in self.answer {
            if let value = self.mappedChars[character.normalizeForHangman], value == false {
                result.append("*")
            } else {
                result.append(character)
            }
        }
        
        return result
    }
    
    var guessedCharacters: [Character] {
        var guessedChars: [Character] = []
        
        for key in self.mappedChars.keys {
            if self.mappedChars[key] == true {
                guessedChars.append(key)
            }
        }
        
        return guessedChars
    }
    
    var lives: Int {
        return Hangman.maxMisguesses - self.misguesses
    }
    
    var isWon: Bool {
        for char in self.normalizedAnswer {
            if let _ = self.mappedChars[char], self.mappedChars[char] == false {
                return false
            }
        }
        
        return !self.isLost
    }
    
    var isLost: Bool {
        return self.misguesses >= Hangman.maxMisguesses
    }
    
    var isOngoing: Bool {
        return !self.isLost && !self.isWon
    }
    
    // METHODS
    
    func newGame(word: String, info: String) {
        self.wordHelpInfo = info
        self.answer = word
        self.misguesses = 0
        for key in self.mappedChars.keys {
            self.mappedChars[key] = false
        }
        
        print("Hangman - ANSWER:", self.answer)
    }
    
    func makeGuess(char: Character) -> Bool {
        let normalizedInput = char.normalizeForHangman
        
        print("Guess: ", normalizedInput, "Answer: ", self.answer)
        
        return self.isValidInput(char: normalizedInput) && self.validateGuess(char: normalizedInput)
    }
    
    func isValidInput(char: Character) -> Bool {
        return self.isOngoing && self.mappedChars[char] == false
    }
    
    func validateGuess(char: Character) -> Bool {
        if self.mappedChars[char] == false {
            self.mappedChars[char] = true
            
            if self.normalizedAnswer.contains(char) {
                return true
            } else {
                self.misguesses += 1
            }
        }
        
        return false
    }
}
