//
//  MusicVolumeManager.swift
//  MOMr_LUAz_201234567_201234567_labo3
//
//  Created by Rébecca Dauphnie Mombrun (Étudiant) on 2023-11-24.
//

import Foundation
import AVFoundation

class MusicManager {
    static let shared = MusicManager()
    
    private var audioPlayer: AVAudioPlayer?

    private init() {}

    func playBackgroundMusic() {
        if let musicURL = Bundle.main.url(forResource: "bg_music", withExtension: "mp3") {
            do {
                audioPlayer = try AVAudioPlayer(contentsOf: musicURL)
                audioPlayer?.numberOfLoops = -1 // infinitely play
                audioPlayer?.prepareToPlay()
                audioPlayer?.play()
            } catch {
                print("Error loading background music: \(error.localizedDescription)")
            }
        }
    }

    func stopBackgroundMusic() {
        audioPlayer?.stop()
    }

    func setVolume(_ volume: Float) {
        audioPlayer?.volume = volume
    }
}
