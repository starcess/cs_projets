//
//  RandomWordAPI.swift
//  MOMr_LUAz_201234567_201234567_labo3
//
//  Created by Paige Wills on 2023-11-20.
//

import Foundation

enum APIError: Error {
    case invalidURL
    case noData
    case decodingError
}

func fetchDataFromAPI(apiURL: URL, completion: @escaping (Result<Data, Error>) -> Void) {
    let config = URLSessionConfiguration.default
    let session = URLSession(configuration: config)
    
    let task = session.dataTask(with: apiURL) { (data, response, error) in
        if let error = error {
            completion(.failure(error))
            return
        }

        guard let data = data else {
            completion(.failure(APIError.noData))
            return
        }

        completion(.success(data))
    }

    task.resume()
}

// for Hangman object, set new games with newGame(movie.title)
func getRandomMovie(completion: @escaping (Result<Movie, Error>) -> Void) {
    let apiUrl = "https://www.omdbapi.com/"
    let apiKey = "b156385c"
    let imdbID = DataList.movieList.randomElement()!
    
    let queryItems = [
        URLQueryItem(name: "i", value: imdbID),
        URLQueryItem(name: "apikey", value: apiKey)
    ]

    var urlComponents = URLComponents(string: apiUrl)
    urlComponents?.queryItems = queryItems

    guard let url = urlComponents?.url else {
        completion(.failure(NSError(domain: "Invalid URL", code: 0, userInfo: nil)))
        return
    }

    URLSession.shared.dataTask(with: url) { data, response, error in
        do {
            if let error = error {
                throw error
            }

            guard let data = data else {
                throw NSError(domain: "No data", code: 0, userInfo: nil)
            }
            
            let responseString = String(data: data, encoding: .utf8)
//            print("Response: \(responseString ?? "No response data")")

            let decoder = JSONDecoder()
            let movie = try decoder.decode(Movie.self, from: data)

            completion(.success(movie))
        } catch {
            completion(.failure(error))
        }
    }.resume()
}




func getRandomWord(completion: @escaping (String?, Error?) -> Void) {
    let apiUrl = "https://random-word-api.herokuapp.com/word"
    
    guard let url = URL(string: apiUrl) else {
        completion(nil, NSError(domain: "Invalid URL", code: 0, userInfo: nil))
        return
    }

    let session = URLSession(configuration: .default)

    let task = session.dataTask(with: url) { (data, response, error) in
        if let error = error {
            completion(nil, error)
            return
        }

        if let safeData = data {
            do {
                let json = try JSONSerialization.jsonObject(with: safeData, options: [])

                if let wordArray = json as? [String] {
                    if let randomWord = wordArray.first {
                        completion(randomWord, nil)
                    } else {
                        completion(nil, NSError(domain: "Empty word array", code: 0, userInfo: nil))
                    }
                } else {
                    completion(nil, NSError(domain: "Invalid response format", code: 0, userInfo: nil))
                }

            } catch {
                completion(nil, error)
            }
        }
    }
    task.resume()
}


func getWordDefinition(word: String, completion: @escaping (Result<String, Error>) -> Void) {
    let apiUrl = "https://api.dictionaryapi.dev/api/v2/entries/en/\(word)"
    
    guard let url = URL(string: apiUrl) else {
        completion(.failure(NSError(domain: "Invalid URL", code: 0, userInfo: nil)))
        return
    }

    let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
        if let error = error {
            completion(.failure(error))
            return
        }

        guard let data = data else {
            completion(.failure(NSError(domain: "No data", code: 0, userInfo: nil)))
            return
        }

        do {
            let dictionaryWords = try JSONDecoder().decode([DictionaryWord].self, from: data)
            if let firstDefinition = dictionaryWords.first?.meanings.first?.definitions.first?.definition {
                completion(.success(firstDefinition))
            } else {
                completion(.failure(NSError(domain: "No definition found", code: 0, userInfo: nil)))
            }
        } catch {
            completion(.failure(error))
        }
    }

    task.resume()
}

func fetchData(url: String) async throws -> Data {
    let validatedURL = URL(string: url)!
    let (data, _) = try await URLSession.shared.data(from: validatedURL)
    
    return data
}



func fetchRandomWordAndDefinition(completion: @escaping (String, String) -> Void) {
    getRandomWord { word, error in
        if let error = error {
            print("Error fetching word: \(error)")
            return
        } else if let word = word {
            print("Random Word: \(word)")

            getWordDefinition(word: word) { result in
                switch result {
                case .success(let definition):
//                    print("Definition of \(word): \(definition)")
                    completion(word, definition)

                case .failure(let error):
                    print("Error getting definition: \(error)")

                    if error is DecodingError {
                        print("Decoding error encountered. Fetching a new word...")
                        fetchRandomWordAndDefinition(completion: completion)
                    }
                }
            }
        } else {
            print("No word received")
        }
    }
}
