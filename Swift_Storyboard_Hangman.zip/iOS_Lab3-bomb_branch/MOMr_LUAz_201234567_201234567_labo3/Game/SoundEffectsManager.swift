//
//  SoundEfectsManager.swift
//  MOMr_LUAz_201234567_201234567_labo3
//
//  Created by Rébecca Dauphnie Mombrun (Étudiant) on 2023-11-26.
//

import Foundation
import AVFoundation
import UIKit


class SoundEffectsManager{
    
    static let shared = SoundEffectsManager()
    
    private var tapSoundPlayer: AVAudioPlayer?
    private var clickSoundPlayer: AVAudioPlayer?
    
    private let soundFiles: [String] = [
    ]
    
    private init() {
        setupSoundPlayer()
    }
    
    private func setupSoundPlayer() {
        
        if let clickURL = Bundle.main.url(forResource: "sfxBtnClicked", withExtension: "mp3") {
            clickSoundPlayer = try? AVAudioPlayer(contentsOf: clickURL)
            clickSoundPlayer?.prepareToPlay()
        }
    }
    
    
    
    func playClickSound() {
        if clickSoundPlayer?.isPlaying == true {
            clickSoundPlayer?.stop()
            clickSoundPlayer?.currentTime = 0
        }
        clickSoundPlayer?.play()
    }
    
    
    func setVolume(_ volume: Float) {
        tapSoundPlayer?.volume = volume
        clickSoundPlayer?.volume = volume
    }
    
}
